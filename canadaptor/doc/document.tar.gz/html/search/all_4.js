var searchData=
[
  ['if_5finfo_13',['if_info',['../structif__info.html',1,'']]],
  ['initialize_14',['initialize',['../classCanAdaptor.html#a81199f0708444d4acba987be93b831c3',1,'CanAdaptor']]]
];
