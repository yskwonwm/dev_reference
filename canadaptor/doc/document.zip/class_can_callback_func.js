var class_can_callback_func =
[
    [ "CanCallbackFunc", "class_can_callback_func.html#ae92ea921bbace3e221826f2d3d0cee5f", null ],
    [ "getCanid", "class_can_callback_func.html#ae23d0b2de0aa3588c988ff38970fd157", null ],
    [ "getChannel", "class_can_callback_func.html#ac2c5122460f222f9c542fd488a1ee9e5", null ],
    [ "getHandler", "class_can_callback_func.html#a18afd0d8869f35e11bb91ea5ee2a381e", null ],
    [ "setHandler", "class_can_callback_func.html#af26b0838fa1776f3955b7fe521c3a701", null ]
];