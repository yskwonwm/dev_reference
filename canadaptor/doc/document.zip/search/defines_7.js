var searchData=
[
  ['put_5feff_5fid_0',['put_eff_id',['../lib_8c.html#a2a22284a0c82da1584b7f91c6d47d83e',1,'lib.c']]],
  ['put_5fsff_5fid_1',['put_sff_id',['../lib_8c.html#a2fb5dda74ca9cc155b23c150092751d9',1,'lib.c']]]
];
