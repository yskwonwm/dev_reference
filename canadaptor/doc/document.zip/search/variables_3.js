var searchData=
[
  ['last_5fdropcnt_0',['last_dropcnt',['../structif__info.html#a322e718550c2e108c30c5b1e4c6cc373',1,'if_info']]]
];
