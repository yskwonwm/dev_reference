var searchData=
[
  ['data_5fseperator_0',['DATA_SEPERATOR',['../lib_8c.html#ae5ff3736fadbe35062020032b42356fb',1,'lib.c']]]
];
