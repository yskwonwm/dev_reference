var structif__info =
[
    [ "cmdlinename", "structif__info.html#a6850d648a96b50c057b4b4a9b63a3553", null ],
    [ "dropcnt", "structif__info.html#a2c685d9aa7f34509bfa4d16d8bacbc7a", null ],
    [ "last_dropcnt", "structif__info.html#a322e718550c2e108c30c5b1e4c6cc373", null ],
    [ "s", "structif__info.html#a41c9036badd1d071d3f5a04a3bc0403b", null ]
];